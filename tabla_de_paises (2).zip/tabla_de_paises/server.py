from flask import Flask, render_template

app = Flask (__name__)

#lista de diccionario con la informacion de los paises
paises = [

   {'pais': 'Argentina' , 'capital': 'Buenos Aires'},
   {'pais': 'Brasil' , 'capital': 'Brasilia'},
   {'pais': 'Chile' , 'capital': 'Santiago de Chile'},
   {'pais': 'Colombia' , 'capital': 'Bogotá'},
   {'pais': 'Costa Rica' , 'capital': 'San José'},
   {'pais': 'Paraguay' , 'capital': 'Asunción'},
   {'pais': 'Perú' , 'capital': 'Lima'}
]

@app.route('/')
def mostrar_paises():
    """Ruta principal que renderiza la plantilla de index.html y le pasa a la lista de paises."""

    return render_template('index.html', paises=paises)

__name__ = str
if __name__ == '__main__':
    app.run(debug=True)
